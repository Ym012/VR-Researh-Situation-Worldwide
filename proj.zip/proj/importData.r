library("RPostgreSQL")
con <- dbConnect(RPostgres::Postgres(), dbname = "project")

##1
#ARTICLE_PUBLISHED_IN_JOURNAL = read.csv("ARTICLE_PUBLISHED_IN_JOURNAL.csv")
#dbWriteTable(con, name = "ARTICLE_PUBLISHED_IN_JOURNAL", value = ARTICLE_PUBLISHED_IN_JOURNAL) 
dbReadTable(con, "ARTICLE_PUBLISHED_IN_JOURNAL")

##2
#COUNTRY_INVESTS_IN_RD = read.csv("COUNTRY_INVESTS_IN_RD_C.csv")
#dbWriteTable(con, name = "COUNTRY_INVESTS_IN_RD", value = COUNTRY_INVESTS_IN_RD) 
dbReadTable(con, "COUNTRY_INVESTS_IN_RD")

##3
#DOI_COUNTRY = read.csv("doi_country_C.csv")
#dbWriteTable(con, name = "DOI_COUNTRY", value = DOI_COUNTRY) 
dbReadTable(con, "DOI_COUNTRY")

##4
JOURNAL = read.csv("JOURNAL_C.csv")
dbWriteTable(con, name = "JOURNAL", value = JOURNAL) 
dbReadTable(con, "JOURNAL")

##5
AUTHORS_WRITE_ARTICLE = read.csv("AUTHORS_WRITE_ARTICLE_C.csv")
dbWriteTable(con, name = "AUTHORS_WRITE_ARTICLE", value = AUTHORS_WRITE_ARTICLE) 
dbReadTable(con, "AUTHORS_WRITE_ARTICLE")

##6
COUNTRY = read.csv("COUNTRY.csv")
dbWriteTable(con, name = "COUNTRY", value = COUNTRY) 
dbReadTable(con, "COUNTRY")

##7
ARTICLE = read.csv("ARTICLE_C.csv")
dbWriteTable(con, name = "ARTICLE", value = ARTICLE) 
dbReadTable(con, "ARTICLE")

##8

LEAD_AUTHOR = read.csv("LEAD_AUTHOR_C.csv")
dbWriteTable(con, name = "LEAD_AUTHOR", value = LEAD_AUTHOR) 
dbReadTable(con, "LEAD_AUTHOR")

