library(shiny)
library(dplyr)
library(ggplot2)
#COUNTRY_INVESTS_IN_RD = COUNTRY_INVESTS_IN_RD = read.csv("COUNTRY_INVESTS_IN_RD_C.csv")
COUNTRY_INVESTS_IN_RD = COUNTRY_INVESTS_IN_RD = read.csv("investment.csv")
ARTICLE_PUBLISHED_IN_JOURNAL = read.csv("ARTICLE_PUBLISHED_IN_JOURNAL.csv")
# Define UI for app that draws a histogram ----
ui <- fluidPage( # auto adjust the window size 
  
  # App title ----
  titlePanel("Research App"),
  
  # Sidebar layout with input and output definitions ----
  sidebarLayout(
    
    # Sidebar panel for inputs ----
    sidebarPanel(
      
      # Input: Slider for the number of bins ----
      sliderInput(inputId = "year",
                  label = h4("Range Of Year"),
                  min = 1981,
                  max = 2020,
                  value = c(2000,2020)),
      checkboxGroupInput("country", label = h4("Location Selection"), inline = TRUE,
                         choices = list(
                           "Argetina" = "ARG", 
                           "Australia" = "AUS", 
                           "Austria" = "AUT",
                           "Belgium" = "BEL",
                           "Canada" = "CAN", 
                           "Chili" = "CHL", 
                           "China" = "CHN",
                           "Colombia" = "COL",
                           "Czech Republic" = "CZE", 
                           "Denmark" = "DNK",
                           "Estonia" = "EST",
                           "Finland" = "FIN", 
                           "France" = "FRA", 
                           "Germany" = "DEU",
                           "Greece" = "GRC",
                           "Hungry" = "HUN",
                           "Iceland" = "ISL",
                           "Ireland" = "IRL",
                           "Israel" = "ISR", 
                           "Italy" = "ITA",
                           "Japan" = "JPN", 
                           "Korea" = "KOR", 
                           "Latvia" = "LVA",
                           "Lithuania" = "LTU", 
                           "Luxemburg" = "LUX",
                           "Mexico" = "MEX",
                           "Neitherland" = "NLD", 
                           "New Zealand" = "NZL", 
                           "Norway" = "NOR",
                           "Poland" = "POL",
                           "Portugal" = "PRT", 
                           "Romania" = "ROU", 
                           "Russia" = "RUS",
                           "Singapore" = "SGP", 
                           "Slovania" = "SVN",
                           "South Africa" = "ZAF", 
                           "Slovakia" = "SVK", 
                           "Spain" = "ESP",
                           "Sweden" = "SWE",
                           "Switzerland" = "CHE", 
                           "Taiwan" = "TWN",
                           "Türkiye" = "TUR", 
                           "United Kingdom" = "GBR",
                           "United States" = "USA",
                           "OECD" = "OECD",
                           "EU" = "EU27_2020"
                           ),
                         selected = c("USA","KOR","CHN", "DEU", "GBR"))
      
    ),
    
    # Main panel for displaying outputs ----
    mainPanel(
      
      # Output: Histogram ----
      plotOutput(outputId = "plot1"),
      #column(4, verbatimTextOutput("range"))
      dataTableOutput('table1'),
      dataTableOutput('table')
    )
  )
)

# Define server logic required to draw a histogram ----
server <- function(input, output) {
  
  #COUNTRY_INVESTS_IN_RD_subset = 
  #  COUNTRY_INVESTS_IN_RD[COUNTRY_INVESTS_IN_RD$LOCATION == input$country, ]
  output$plot1 = renderPlot({
    ggplot(COUNTRY_INVESTS_IN_RD[COUNTRY_INVESTS_IN_RD$LOCATION == input$country &
                                   COUNTRY_INVESTS_IN_RD$TIME>=input$year[1] &
                                   COUNTRY_INVESTS_IN_RD$TIME<=input$year[2] , ]) +
      #geom_line(mapping = aes(x = TIME, y = Value, colour = LOCATION), size = 1.5) + 
      geom_line(mapping = aes(x = TIME, y = Percentage, colour = LOCATION), size = 1.5) + 
      #geom_point(mapping = aes(x = TIME, y = Value, colour = LOCATION), size = 2)+
      scale_x_continuous(breaks=seq(input$year[1], input$year[2], 2))+
      theme_classic() +
      labs (x = "Years", y = "% of GDP", title = "Expenditures on R&D") + 
      scale_colour_discrete(name = "Country/Region")+
      theme(text = element_text(size=20))
  })
  output$table1 <- renderDataTable(COUNTRY_INVESTS_IN_RD[COUNTRY_INVESTS_IN_RD$LOCATION == input$country &
                                                           COUNTRY_INVESTS_IN_RD$TIME>=input$year[1] &
                                                           COUNTRY_INVESTS_IN_RD$TIME<=input$year[2] , ],
                                   options = list(pageLength = 10))
  output$table <- renderDataTable(ARTICLE_PUBLISHED_IN_JOURNAL%>% 
                                    group_by(Journal_Name) %>% summarise(counts = n()) %>% arrange(desc(counts)),
                                  options = list(pageLength = 10))
  #x = list(input$country)
  #output$range <- renderPrint({ input$country })
  #output$range <- renderPrint({ x })
  
}

shinyApp(ui = ui, server = server)
